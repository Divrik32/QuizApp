import "./app.css";
import Quiz from "./Components/Quiz";

function App() {
  return (
    <div className="app">
      <Quiz />
    </div>
  );
}

export default App;
