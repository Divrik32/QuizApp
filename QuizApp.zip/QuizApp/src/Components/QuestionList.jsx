import React from "react";

const QuestionList = ({ question, options,handleClick,currentAnswer }) => {

  return (
    <div>
      <h2>{question}</h2>
      <ul>{options.map((option,index)=>(
        <li onClick={()=>handleClick(option)} className={currentAnswer===option?"selected":""} key={index}>{option}</li>
      ))}</ul>
    </div>
  );
};

export default QuestionList;
