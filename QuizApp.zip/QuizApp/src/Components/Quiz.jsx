import React, { useState } from "react";
import QuestionList from "./QuestionList";
import "./Quiz.css";
import { Button, Typography } from "@mui/material";

const Quiz = () => {
  const questions = [
    {
      question: "What is the capital of France?",
      options: ["Berlin", "Madrid", "Paris", "Rome"],
      answer: "Paris",
    },
    {
      question: "Who painted the Mona Lisa?",
      options: [
        "Vincent van Gogh",
        "Leonardo da Vinci",
        "Pablo Picasso",
        "Claude Monet",
      ],
      answer: "Leonardo da Vinci",
    },
    {
      question: "Which planet is known as the Red Planet?",
      options: ["Earth", "Mars", "Jupiter", "Saturn"],
      answer: "Mars",
    },
    {
      question: "What is the largest ocean on Earth?",
      options: [
        "Atlantic Ocean",
        "Indian Ocean",
        "Southern Ocean",
        "Pacific Ocean",
      ],
      answer: "Pacific Ocean",
    },
    {
      question: "What is the boiling point of water?",
      options: ["100°C", "90°C", "110°C", "120°C"],
      answer: "100°C",
    },
    {
      question: "Who wrote 'Romeo and Juliet'?",
      options: [
        "Charles Dickens",
        "William Shakespeare",
        "Jane Austen",
        "Mark Twain",
      ],
      answer: "William Shakespeare",
    },
    {
      question: "What is the smallest country in the world?",
      options: ["Vatican City", "Monaco", "Nauru", "San Marino"],
      answer: "Vatican City",
    },
    {
      question: "What is the longest river in the world?",
      options: [
        "Amazon River",
        "Nile River",
        "Yangtze River",
        "Mississippi River",
      ],
      answer: "Nile River",
    },
    {
      question: "How many continents are there?",
      options: ["5", "6", "7", "8"],
      answer: "7",
    },
    {
      question: "Who is known as the father of modern physics?",
      options: [
        "Isaac Newton",
        "Albert Einstein",
        "Galileo Galilei",
        "Nikola Tesla",
      ],
      answer: "Albert Einstein",
    },
  ];

  const [currentQuestinIndex, setCurrentQuestionIndex] = useState(0);
  const [currentAnswer, setCurrentAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const handleClick = (option) => {
    setCurrentAnswer(option);
    if (option === questions[currentQuestinIndex].answer) {
      setScore(score + 1);
    }
  };
  const handleNextQuestion = () => {
    setCurrentQuestionIndex(currentQuestinIndex + 1);
    setCurrentAnswer(null);
  };
  return (
    <div>
      {currentQuestinIndex < questions.length ? (
        <div>
          <QuestionList
            question={questions[currentQuestinIndex].question}
            options={questions[currentQuestinIndex].options}
            currentAnswer={currentAnswer}
            handleClick={handleClick}
          />

          <button
            onClick={handleNextQuestion}
            disabled={currentAnswer === null}
            className={currentAnswer === null ? "button-disabled" : "button"}
          >
            Next Question
          </button>
        </div>
      ) : (
        <div>
          <Typography variant="h4" gutterBottom>
            Your score is {score}
          </Typography>
          <br />
          <div>
            {" "}
            <Button
              variant="contained"
              onClick={() => window.location.reload()}
              sx={{
                width: "100%",
                padding: "12px",
                fontSize: "16px",
                backgroundColor: "#f50077",
                "&:hover": {
                  backgroundColor: "secondary.main", // You can change this to any color or styling you prefer
                  transform: "scale(1.05)", // Optional: Adds a scaling effect on hover
                },
              }}
            >
              Restart Quiz
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Quiz;
